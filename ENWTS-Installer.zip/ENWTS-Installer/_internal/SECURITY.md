# Security Policy

## Supported Versions

Only the latest published version is supported.

## Reporting a Vulnerability

If you believe you have found a security issue in ENWTS:

- Do **not** post public exploit details.
- Provide a clear description, steps to reproduce, and the impacted environment.

(Replace this section with your preferred contact method before publishing.)
