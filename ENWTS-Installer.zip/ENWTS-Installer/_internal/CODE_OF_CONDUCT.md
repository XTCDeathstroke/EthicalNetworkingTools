# Code of Conduct

Be respectful.

- No harassment or hate speech.
- No doxxing.
- No malicious-use requests or contributions.

Project maintainers may remove or reject content that violates these expectations.
