# Changelog

## 1.0.0

- Initial combined release of:
  - LAN Discovery
  - Net Probe
  - Port Scope
- Added max-runtime safety stops, export/save functions, and unified multi-tab UI.
